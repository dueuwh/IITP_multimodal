import os
import sys
import matplotlib.pyplot as plt
import mediapipe as mp
import cv2
import numpy as np

def preprocess():
    