import numpy as np
import torch

class tokenizer():
    def __init__(self, method):
        self.method = method
        
        